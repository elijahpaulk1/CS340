from pymongo import MongoClient

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password, host='localhost', port=27017, db='aac', collection='animals'):
        # Connection Variables
        self.USER = username
        self.PASS = password
        self.HOST = host
        self.PORT = port
        self.DB = db
        self.COL = collection
        #
        # Initialize Connection
        #
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (self.USER, self.PASS, self.HOST, self.PORT))
        self.database = self.client[self.DB]
        self.collection = self.database[self.COL]

    # Complete this create method to implement the C in CRUD.
    def create(self, data):
        """
        Inserts a document into the specified MongoDB database and collection.

        Args:
        - data (dict): A set of key/value pairs in the data type acceptable to the MongoDB driver insert API call.

        Returns:
        - bool: True if successful insert, else False.
        """
        if data is not None:
            result = self.collection.insert_one(data)
            return True if result.inserted_id else False
        else:
            raise Exception("Nothing to save because the data parameter is empty")

    # Create method to implement the R in CRUD.
    def read(self, query):
        """
        Queries for documents from the specified MongoDB database and collection.

        Args:
        - query (dict): The key/value lookup pair to use with the MongoDB driver find API call.

        Returns:
        - list: Result in a list if the command is successful, else an empty list.
        """
        result = self.collection.find(query)
        return list(result) if result else []
